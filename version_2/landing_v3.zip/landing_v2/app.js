const h1 = document.getElementById('name')

const sphereOne = document.querySelector('.one')
const sphereTwo = document.querySelector('.two')
const sphereThree = document.querySelector('.three')

const texts = ["Produccion", "Distribucion" ,"Teleoperarios"];
let iterador = 0;

let sphereOneTopVar = 130
let sphereTwoTopVar = 280
let sphereThreeTopVar = 180


setInterval(() => {
  if (iterador === 3) {
    return iterador = 0;
  }
  // console.log(texts[iterador]);
  // console.log(iterador);
  if(iterador === 0){
    h1.style.color = '#9C82BD'
    h1.style.transition = '.5s';
  }else if(iterador === 1){
    h1.style.color = '#F06C74'
    h1.style.transition = '.5s';
  }else{
    h1.style.color = '#FFBB37'
    h1.style.transition = '.5s';
  }

  h1.textContent = `${texts[iterador]}`
  h1.style.fontSize = "1.8rem"

  sphereOneTopFunc()
  sphereTwoTopFunc()
  sphereThreeTopFunc()

  iterador ++;
}, 2000);


const sphereOneTopFunc = () =>{
    if(sphereOneTopVar === 130){
        sphereOne.style.top = '190px';
        sphereOne.style.left = '170px';
        // sphereOne.style.background = 'violet';
        sphereOne.style.zIndex = '4'
        sphereOne.style.transform = 'perspective(0px) translateZ(0px)'
        sphereOne.style.transition = '.5s';
        sphereOneTopVar = 180
    }else if (sphereOneTopVar === 180){
      sphereOne.style.top = '30px';
      sphereOne.style.left = '130px';
      // sphereOne.style.background = 'blue';
      sphereOne.style.zIndex = '3'
      sphereOne.style.transform = 'perspective(10px) translateZ(-11px)'
      sphereOne.style.transition = '.5s';
      sphereOneTopVar = 280
    }else{
      sphereOne.style.top = '90px';
      sphereOne.style.left = '60px';
      // sphereOne.style.background = 'red';
      sphereOne.style.zIndex = '3'
      sphereOne.style.transform = 'perspective(10px) translateZ(-11px)'
      sphereOne.style.transition = '.5s ease-in-out';
      sphereOneTopVar = 130
    }
}

const sphereTwoTopFunc = () =>{
    if(sphereTwoTopVar === 280){
        sphereTwo.style.top = '30px';
        sphereTwo.style.left = '130px';
        // sphereTwo.style.background = 'yellow';
              '2'
        sphereTwo.style.transform = 'perspective(10px) translateZ(-11px)'
        sphereTwo.style.transition = '.5s ease-in-out';
        sphereTwoTopVar = 180
    }else if (sphereTwoTopVar === 130){
      sphereTwo.style.top = '190px';
      sphereTwo.style.left = '170px';
      // sphereTwo.style.background = 'green';
            '4'
      sphereTwo.style.transform = 'perspective(0px) translateZ(0px)'
      sphereTwo.style.transition = '.5s ease-in-out';
      sphereTwoTopVar = 280
    }else{
      sphereTwo.style.top = '90px';
      // sphereTwo.style.transform = 'translateY(-50px)';    
      sphereTwo.style.left = '60px';
      // sphereTwo.style.background = 'gray';
            '3'
      sphereThree.style.transform = 'perspective(10px) translateZ(-11px)'
      sphereTwo.style.transition = '.5s ease-in-out';
      sphereTwoTopVar = 130
    }
}

const sphereThreeTopFunc = () =>{
    if(sphereThreeTopVar === 180){
        sphereThree.style.top = '90px';
        sphereThree.style.left = '60px';
        // sphereThree.style.background = 'black';
        sphereThree.style.zIndex = '3';
        sphereThree.style.transform = 'perspective(10px) translateZ(-11px)'
        sphereThree.style.transition = '.5s';
        sphereThreeTopVar = 280
    }else if (sphereThreeTopVar === 280){
      sphereThree.style.top = '190px';
      sphereThree.style.left = '170px';
      // sphereThree.style.background = 'brown';
      sphereThree.style.zIndex = '4'
      sphereThree.style.transform = 'perspective(0px) translateZ(0px)'
      sphereThree.style.transition = '.5s';
      sphereThreeTopVar = 130
    }else{
      sphereThree.style.top = '30px';
      sphereThree.style.left = '130px';
      sphereThree.style.transform = 'perspective(10px) translateZ(-11px)'
      // sphereThree.style.background = 'lightblue';
      sphereThree.style.zIndex = '1'
      sphereThree.style.transition = '.5s';
      sphereThreeTopVar = 180
    }
}